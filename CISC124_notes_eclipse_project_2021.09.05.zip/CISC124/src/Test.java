import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		String sum = scanner.next();
		if (sum == "2+2") {
		    System.out.println(" = 4");
		}
		
		int min = 59;
		int x = Integer.MAX_VALUE - 7 + 1;
		System.out.println(min + x);
		System.out.println(min + x % 60);
		
		System.out.println(Integer.MAX_VALUE - 7);
	}
}
