package ca.queensu.cs.cisc124.notes.generics.list;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.StringJoiner;

/**
 * A linked node-based implementation of a {@code SList}.
 *
 * @param <E> the type of elements in this list
 */
public class SLinkedList<E> implements SList<E> {

	static class Node<E> {
        E elem;
        Node<E> next;

        /**
         * Initializes a node to refer to the specified element and node.
         * 
         * @param c a character
         */
        public Node(E elem, Node<E> node) {
            this.elem = elem;
            this.next = node;
        }
    }

    /**
     * The number of elements in the linked list.
     */
    private int size;

    /**
     * The first node of the linked list; will be <code>null</code> for an empty
     * list.
     */
    private Node<E> head;

    /**
     * The last node of the linked list; will be <code>null</code> for an empty
     * list.
     */
    private Node<E> tail;

    
    /**
     * Returns the head node of this list.
     * 
     * @return the head node of this list
     */
    Node<E> head() {
        return this.head;
    }
    
    /**
     * Returns the tail node of this list.
     * 
     * @return the tail node of this list
     */
    Node<E> tail() {
        return this.tail;
    }
    
    
    /**
     * Initialize an empty list.
     */
    public SLinkedList() {
        this.size = 0;
        this.head = null;
        this.tail = null;
    }

    /**
     * Get the number of elements in the list.
     * 
     * @return the number of elements in the list.
     */
    @Override
    public int size() {
        return this.size;
    }
    
    /**
     * Adds the given element to the end of the list.
     * 
     * @param elem the element to add
     */
    @Override
    public void add(E elem) {
        if (this.size == 0) {
            this.head = new Node<>(elem, null);
            this.tail = this.head;
        } else {
            Node<E> n = new Node<>(elem, null);
            this.tail.next = n;
            this.tail = n;
        }
        this.size++;
    }

    /**
     * Validates the specified index.
     * 
     * @param index an index
     * @throws IndexOutOfBoundsException if
     *                                   {@code index < 0 || index >= this.size()}
     */
    void validate(int index) {
        if (index < 0 || index >= this.size) {
            throw new IndexOutOfBoundsException("index out of bounds: " + index);
        }
    }

    /**
     * Returns the node at the specified index. Assumes that the index is valid for
     * this list to avoid re-validating the index.
     * 
     * @param index a valid index for this list
     * @return the node at the specified index
     */
    Node<E> moveTo(int index) {
        Node<E> n = this.head;
        for (int i = 0; i < index; i++) {
            n = n.next;
        }
        return n;
    }

    /**
     * Returns the element at the specified position in the list.
     * 
     * @param index index of the element to return
     * @return the element at the specified position
     * @throws IndexOutOfBoundsException if the index is out of the range
     *                                   {@code (index < 0 || index >= size())}
     */
    @Override
    public E get(int index) {
        this.validate(index);
        Node<E> n = this.moveTo(index);
        return n.elem;
    }

    /**
     * Sets the element at the specified position in the list.
     * 
     * @param index index of the element to set
     * @param elem element to be stored at the specified position
     * @throws IndexOutOfBoundsException if the index is out of the range
     *                                   {@code (index < 0 || index >= size())}
     */
    @Override
    public E set(int index, E elem) {
        this.validate(index);
        Node<E> n = this.moveTo(index);
        E old = n.elem;
        n.elem = elem;
        return old;
    }

    /**
     * Adds an element to the front of this list.
     * 
     * @param elem the element to add
     */
    public void addFront(E elem) {
        Node<E> toAdd = new Node<>(elem, null);
        toAdd.next = this.head;
        this.head = toAdd;
        this.size++;
    }

    /**
     * Inserts an element at the specified index of this list. Shifts the element
     * currently at that position (if any) and any subsequent elements to the right.
     * 
     * @param index the index at which to add the element
     * @param elem  the element to add
     * @throws IndexOutOfBoundsException if the index is out of the range
     *                                   {@code (index < 0 || index > size())}
     */
    @Override
    public void add(int index, E elem) {
    	
    	// WARNING: THERE IS A BUG IN THIS METHOD
    	
        if (index == this.size) {
            // add to end
            this.add(elem);
            //return;             bug here
        }
        // must validate after the previous if statement otherwise
        // an exception will be thrown because this.size is not a valid index
        this.validate(index);

        if (index == 0) {
            this.addFront(elem);
        } else {
            Node<E> n = this.moveTo(index - 1);
            Node<E> toAdd = new Node<>(elem, null);
            Node<E> after = n.next;
            n.next = toAdd;
            toAdd.next = after;
            this.size++;
        }
    }

    /**
     * Removes the first element of this list and returns the element.
     * 
     * @return the removed element
     * @throws NoSuchElementException if the list is empty
     */
    public E removeFront() {
        if (this.size == 0) {
            throw new NoSuchElementException("list is empty");
        }
        Node<E> toRemove = this.head;
        this.head = toRemove.next;
        // special case of removing from a list of size 1
        if (this.size == 0) {
            this.tail = null;
        }
        this.size--;
        return toRemove.elem;
    }

    /**
     * Removes the element at the specified index of this list, shifts any
     * subsequent elements to the left (subtracts one to their indices), and returns
     * a reference to the removed element.
     * 
     * @param index the index of the element to remove
     * @return the removed element
     * @throws IndexOutOfBoundsException if the index is out of the range
     *                                   {@code (index < 0 || index >= size())}
     */
    @Override
    public E remove(int index) {
        if (index == 0) {
            return this.removeFront();
        }
        this.validate(index);
        Node<E> n = this.moveTo(index - 1);
        return this.removeAfter(n);
        
    }
    
    /**
     * Removes the node immediately after the specified node.
     * 
     * @param n the node in front of the node to be removed
     * @return the element in the removed node
     */
    E removeAfter(Node<E> n) {
    	Node<E> toRemove = n.next;
        Node<E> after = toRemove.next;
        toRemove.next = null;
        n.next = after;
        // special case where the last element was removed
        if (after == null) {
            this.tail = n;
        }
        this.size--;
        return toRemove.elem;
    }
    
    @Override
    public String toString() {
    	
    	StringJoiner j = new StringJoiner(", ", "[", "]");
    	Node<E> n = this.head;
    	for (int i = 0; i < this.size; i++) {
    		j.add(n.elem.toString());
    		n = n.next;
    	}
    	return j.toString();
    	
    	//return "[" + this.toString(this.head) + "]";
    }
    
    private String toString(Node<E> n) {
    	if (n == null) {
    		return "";
    	}
    	if (n.next == null) {
    		return n.elem.toString();
    	}
    	return n.elem.toString() + ", " + toString(n.next);
    }
    
    /**
     * Returns an iterator over the elements in this list. The iterator visits
     * the elements of this list in the order that the elements appear in this list.
     * 
     * @return an iterator over the elements in this list
     */
    @Override
    public Iterator<E> iterator() {
    	return new LLIterator();
    }
    
    private class LLIterator implements Iterator<E> {
		/**
         * Node holding element immediately before the iterator
         */
		private Node<E> prev;
		
		/**
         * Node immediately before prev
         */
		private Node<E> prevPrev;
		
		LLIterator() {
			this.prev = new Node<>(null, SLinkedList.this.head);
			this.prevPrev = null;
		}
		
		@Override
		public boolean hasNext() {
			return this.prev.next != null;
		}
		
		@Override
		public E next() {
			if (!this.hasNext()) {
				throw new NoSuchElementException();
			}
			E e = this.prev.next.elem;
			this.prevPrev = this.prev;
			this.prev = this.prev.next;
			return e;
		}
		
		@Override
		public void remove() {
			if (this.prevPrev == null) {
				throw new IllegalStateException();
			}
			if (this.prev == SLinkedList.this.head) {
				SLinkedList.this.removeFront();
				this.prev.elem = null;
			}
			else {
				SLinkedList.this.removeAfter(this.prevPrev);
				this.prev = this.prevPrev;
			}
			this.prevPrev = null;
		}
	}
    
    
	public static void main(String[] args) {
		SList<Integer> t = new SLinkedList<>();
		for (int i = -5; i <= 6; i++) {
		    t.add(i);
		    t.add(-i);
		}
		System.out.println(t);

		for (Iterator<Integer> iter = t.iterator(); iter.hasNext(); ) {
		    Integer val = iter.next();
		    System.out.println(val);
		    if (val < 0) {
		        iter.remove();    // can call remove once for each call to next
			    System.out.println("removed " + val + " : " + t);
		    }
		    else {
		    	System.out.println("no remove " + val + " : " + t);
		    }
		}
		System.out.println(t);
		
		t.remove(2);
		System.out.println(t);
	}

}
