package ca.queensu.cs.cisc124.notes.inheritance.shapes;

public class RectangleUtil {

	/**
	 * Options for {@code setAspectRatio}.
	 *
	 */
	public enum Options {
        KEEP_CURRENT_WIDTH,
        KEEP_CURRENT_HEIGHT
    }
    
    /**
     * Sets the dimensions of the specified rectangle so that it has the
     * specified aspect ratio. If changing the dimensions of the shape
     * causes the dimensions of the shape to become out of range then
     * this method leaves the dimensions of the shape unchanged and returns
     * false.
     * 
     * <p>
     * The opt parameter specifies whether the method should keep the current
     * width or the current height when changing the dimensions of the shape.
     *
     * @param r a rectangle
     * @param aspectRatio the desired aspect ratio
     * @param opt the option controlling which dimension should remain the same
     * @return true if the dimensions of the rectangle are successfully changed,
     *     false otherwise
     */
    public static boolean setAspectRatio(Rectangle r, double aspectRatio, Options opt) {
        double w = r.width();
        double h = r.height();
        if (opt == Options.KEEP_CURRENT_WIDTH) {
            h = w / aspectRatio;
            if (h < Shape.MIN_LENGTH || h > Shape.MAX_LENGTH) {
                return false;
            }
        }
        else {
            w = h * aspectRatio;
            if (w < Shape.MIN_LENGTH || w > Shape.MAX_LENGTH) {
                return false;
            }
        }
        r.setDimensions(w, h);
        return true;
    }
}
