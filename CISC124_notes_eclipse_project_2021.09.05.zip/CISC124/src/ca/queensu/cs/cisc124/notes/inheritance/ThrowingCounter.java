package ca.queensu.cs.cisc124.notes.inheritance;

/**
 * A counter that throws an exception when attempting to count past {@code Integer.MAX_VALUE}.
 *
 */
public class ThrowingCounter extends Counter {
    // no fields!
    
	/**
     * Initialize this counter to a count of zero.
     */
    public ThrowingCounter() {
        super();
    }
    
    /**
     * Initialize this counter to the specified count value.
     * 
     * @param value the count value of this counter
     */
    public ThrowingCounter(int value) {
        super(value);
    }
    
    /**
     * Increment the value of this counter upwards by 1. If this method is
     * called when the current value of this counter is equal to
     * {@code Integer.MAX_VALUE} then an {@code IllegalStateException} is thrown.
     * 
     * @throws IllegalStateException
     *             if this method is called when the counter is at its 
     *             maximum value
     */
    @Override
    public void advance() {
        if (this.value != Integer.MAX_VALUE) {
            this.value++;
        }
        else {
            throw new IllegalStateException();
        }
    }
    
}