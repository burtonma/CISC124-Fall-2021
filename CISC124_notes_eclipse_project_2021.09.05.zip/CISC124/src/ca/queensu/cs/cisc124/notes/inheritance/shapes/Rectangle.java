package ca.queensu.cs.cisc124.notes.inheritance.shapes;

/**
 * A rectangle shape.
 *
 */
public class Rectangle extends Shape {
    
    /**
     * Initialize this rectangle to a width and height of 1.
     */
    public Rectangle() {
        super();
    }
    
    /**
     * /**
     * Initialize this rectangle to the specified width and height.
     *
     * @param width the width of this rectangle
     * @param height the height of this rectangle
     * @throws IllegalArgumentException if either width or height or is out of range
     */
    public Rectangle(double width, double height) {
    	super.setDimensions(width, height);
    }
}
