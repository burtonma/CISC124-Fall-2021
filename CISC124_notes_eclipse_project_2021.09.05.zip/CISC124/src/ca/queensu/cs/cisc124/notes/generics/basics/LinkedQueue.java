package ca.queensu.cs.cisc124.notes.generics.basics;

/**
 * A linked-list implementation of the {@code Queue} interface.
 *
 * @param <E> the type of the elements in the queue
 */
public class LinkedQueue<E> implements Queue<E> {
    // the number of elements currently in the queue
    private int size;
    
    // the nodes containing the front and back elements of the queue
    private Node<E> front;
    private Node<E> back;
    
    // static nested class representing nodes of the linked list
    private class Node<E> {
            
        // the element stored in the node
        E elem;
    
        // the link to the next node in the sequence
        Node<E> next;
    
        Node(E elem, Node<E> next) {
            this.elem = elem;
            this.next = next;
        }
    }
    
    
    /**
     * Initialize an empty queue.
     */
    public LinkedQueue() {
        this.size = 0;
        this.front = null;
        this.back = null;
    }


    @Override
    public int size() {
        return this.size;
    }


    @Override
    public void enqueue(E elem) {
        Node<E> n = new Node<>(elem, null);
        if (this.isEmpty()) {
        	this.front = n;
        }
        else if (this.size == 1) {
        	this.front.next = n;
        	this.back.next = n;
        }
        else {
        	this.back.next = n;
        }
    	this.back = n;
        this.size++;
    }


    @Override
    public E dequeue() {
        if (this.isEmpty()) {
            throw new RuntimeException("dequeued an empty queue");
        }
        E elem = this.front.elem;
        this.front = this.front.next;
        this.size--;
        if (this.isEmpty()) {
        	this.back = null;
        }
        return elem;
    }
    
    @Override
    public E front() {
    	if (this.size() == 0) {
    		throw new RuntimeException("no front element in an empty queue");
    	}
    	return this.front.elem;
    }
    
    @Override
    public E back() {
    	if (this.size() == 0) {
    		throw new RuntimeException("no back element in an empty queue");
    	}
    	return this.back.elem;
    }
    
    @Override
    public String toString() {
    	StringBuilder b = new StringBuilder("[");
    	Node<E> n = this.front;
		for (int i = 0; i < this.size - 1; i++) {
			b.append(n.elem);
			b.append(", ");
			n = n.next;
		}
		if (!this.isEmpty()) {
			b.append(this.back.elem);
		}
		b.append("]");
		
		return b.toString();
    }
    
    
    public static void main(String[] args) {
        Queue<String> q = new LinkedQueue<>();
        q.enqueue("A");
        q.enqueue("B");
        q.enqueue("C");
        System.out.println("size: " + q.size());
        System.out.println(q);
        System.out.println();
        
        String dq = q.dequeue();
        System.out.println("dq: " + dq);
        System.out.println("size: " + q.size());
        System.out.println(q);
        System.out.println();
        
        dq = q.dequeue();
        System.out.println("dq: " + dq);
        System.out.println("size: " + q.size());
        System.out.println(q);
        System.out.println();
        
        dq = q.dequeue();
        System.out.println("dq: " + dq);
        System.out.println("size: " + q.size());
        System.out.println(q);
        System.out.println();
        
        // force an exception
        q.dequeue();
    }
}
