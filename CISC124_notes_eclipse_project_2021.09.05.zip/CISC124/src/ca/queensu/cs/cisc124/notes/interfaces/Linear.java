package ca.queensu.cs.cisc124.notes.interfaces;

/**
 * Linear functions of the form y = m * x + k where m is the slope and
 * k is y-intercept.
 */
public class Linear implements Function1 {

	private double m;
	private double k;
	
	public Linear(double slope, double intercept) {
		this.m = slope;
		this.k = intercept;
	}
	
	@Override
	public double eval(double x) {
		return m * x + k;
	}

	@Override
	public String toString() {
		return String.format("linear: slope = %f, intercept = %f", this.m, this.k);
	}
}
