package ca.queensu.cs.cisc124.notes.generics.intro;

import java.util.ArrayList;

/**
 * A {@code Stack} represents a last-in-first-out (LIFO) stack of
 * objects. In addition to the usual push and pop methods, this class
 * allows the user to get the number of objects in a stack and to query
 * if the stack is empty.
 * 
 * <p>
 * Users of this class must cast the popped elements to the desired
 * type when required.
 */
public class ListObjectStack {

    private ArrayList<Object> stack;                         // list of Object
    
    
    /**
     * Initializes an empty stack. 
     */
    public ListObjectStack() {
        this.stack = new ArrayList<>();
    }

    /**
     * Returns the number of elements in this stack.
     * 
     * @return the number of elements in this stack
     */
    public int size() {
        return this.stack.size();
    }

    /**
     * Pushes the specified element on to the top of this stack.
     * 
     * @param elem the element to be pushed on to the top of this stack
     */
    public void push(Object elem) {                          // push an object onto the stack
        this.stack.add(elem);
    }

    /**
     * Removes the element on the top of this stack and returns the element.
     * 
     * @return the top element of this stack
     * @throws RuntimeException if the stack is empty
     */
    public Object pop() {                                    // pop an object from the stack
        Object elem = this.stack.remove(this.size() - 1);    // remove an object from the end of the list
        return elem;
    }

    /**
     * Returns a string representation of this stack. The elements of the stack
     * appear in the returned string in sequence starting from the top of the
     * stack to the bottom of the stack with each element separated from the
     * next using a newline character.
     * 
     * @return a string representation of this stack
     */
    public String toString() {
        StringBuilder b = new StringBuilder("ObjectStack:");
        if (this.size() != 0) {
            for (int i = this.size() - 1; i >= 0; i--) {
                b.append('\n');
                b.append(this.stack.get(i));
            }
        }
        return b.toString();
    }
}
