package ca.queensu.cs.cisc124.notes.interfaces;

/**
 * The function y = x * x truncated to the domain {@code -1 < x < 1}.
 *
 */
public class TruncatedSquare implements Function1 {

	@Override
	public double eval(double x) {
		double y = Double.NaN;
		if (Math.abs(x) < 1) {
			y = x * x;
		}
		return y;
	}

	@Override
	public String toString() {
		return "truncated square";
	}
}
