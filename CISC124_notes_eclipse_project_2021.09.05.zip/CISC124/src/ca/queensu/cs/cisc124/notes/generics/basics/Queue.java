package ca.queensu.cs.cisc124.notes.generics.basics;

/**
 * The {@code Queue} interface represents a first-in-first-out (FIFO) queue
 * of elements. In addition to the usual enqueue and dequeue methods, this interface 
 * allows the user to get the number of elements in a queue, query if the queue is empty,
 * and get the first and last elements of the queue without modifying the queue.
 *
 * @param <E> the type of the elements in the queue
 */
public interface Queue<E> {

	/**
	 * Returns the number of elements in this queue.
	 * 
	 * @return the number of elements in this queue
	 */
	public int size();

	/**
	 * Returns {@code true} if this queue contains no elements. The default
	 * implementation simply returns {@code size() == 0}.
	 * 
	 * @return true if this queue contains no elements
	 */
	default boolean isEmpty() {
		return this.size() == 0;
	}

	/**
	 * Adds the specified element to the back of this queue.
	 * 
	 * @param elem the element to be added to the back of this queue
	 */
	public void enqueue(E elem);

	/**
	 * Removes the element from the front of this queue and returns the element.
	 * 
	 * @return the front element of this queue
	 * @throws RuntimeException if this queue is empty
	 */
	public E dequeue();

	/**
	 * Looks at the element at the front this queue without removing it from the
	 * queue.
	 * 
	 * @return the element at the front of this queue
	 * @throws RuntimeException if this queue is empty
	 */
	public E front();
	
	/**
	 * Looks at the element at the back this queue without removing it from the
	 * queue.
	 * 
	 * @return the element at the back of this queue
	 * @throws RuntimeException if this queue is empty
	 */
	public E back();
}
