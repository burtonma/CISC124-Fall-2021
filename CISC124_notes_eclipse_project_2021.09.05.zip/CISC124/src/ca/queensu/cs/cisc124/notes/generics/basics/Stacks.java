package ca.queensu.cs.cisc124.notes.generics.basics;

import java.util.Collection;

/**
 * Generic utility methods for operating on {@code Stack} instances.
 *
 */
public class Stacks {

	/**
	 * Removes all elements from the specified stack.
	 * 
	 * @param <T> the type of elements in the stack
	 * @param s   a stack
	 */
	public static <T> void clear(Stack<T> s) {
		while (s.size() > 0) {
			s.pop();
		}
	}

	/**
	 * Pushes all of the elements in the source collection onto the destination
	 * stack without modifying the source collection.
	 * 
	 * @param <T>  the type of elements in the stack
	 * @param src  the source collection
	 * @param dest the destination stack
	 */
	public static <T> void pushAll(Collection<T> src, Stack<T> dest) {
		for (T elem : src) {
			dest.push(elem);
		}
	}

	/**
	 * Pops all of the elements off of the source stack and adds them to the
	 * destination collection.
	 * 
	 * @param <T>  the type of elements in the stack
	 * @param src  the source stack
	 * @param dest the destination collection
	 */
	public static <T> void popAll(Stack<T> src, Collection<T> dest) {
		while (src.size() > 0) {
			dest.add(src.pop());
		}
	}

	/**
	 * Returns {@code true} if the specified stack contains at least one element
	 * equal to the specified object, and {@code false} otherwise. The stack appears
	 * unmodified to the caller after the method completes.
	 * 
	 * @param <T> the type of elements in the stack
	 * @param s   a stack
	 * @param obj and object
	 * @return true if the specified stack contains at least one element equal to
	 *         the specified object, and false otherwise
	 */
	public static <T> boolean contains(Stack<T> s, Object obj) {
		boolean result = false;
		Stack<T> tmp = new ArrayStack<>();

		// pop elements from s until obj is found (but don't pop an empty stack!)
		// store popped elements in tmp
		while (s.size() > 0 && !result) {
			T elem = s.pop();
			if (elem.equals(obj)) {
				result = true;
			}
			tmp.push(elem);
		}

		// pop elements from tmp back onto s so that the state of
		// s appears unchanged to the caller
		while (tmp.size() > 0) {
			s.push(tmp.pop());
		}
		return result;
	}
}