package ca.queensu.cs.cisc124.notes.inheritance.shapes;

/**
 * A square shape.
 *
 * <p>
 * THIS IS AN EXAMPLE OF THE INCORRECT USE OF INHERITANCE. The {@code Shape} base class
 * says that shapes have an independent width and height, but a square has an equal
 * width and height.
 */
public class Square extends Rectangle {
    
	/**
     * Initialize this square to a width and height of 1.
     */
    public Square() {
        super();
    }
    
    /**
     * Changes both the width and height of this shape to the specified
     * dimensions. The width and height must be greater than or equal to 1, and
     * the width and height must be equal.
     *
     * @param width the width of the shape
     * @param height the height of the shape
     * @throws IllegalArgumentException if either width or height or is out of range,
     * or if the width and height are not equal
     */
    @Override
    public void setDimensions(double width, double height) {
        if (width < MIN_LENGTH || height < MIN_LENGTH) {
            throw new IllegalArgumentException("dimension too small");
        }
        if (width > MAX_LENGTH || height > MAX_LENGTH) {
            throw new IllegalArgumentException("dimension too large");
        }
        if (width != height) {                         // uh, oh, overriding method adds an extra constraint
            throw new IllegalArgumentException("width must be equal to height");
        }
        this.width = width;
        this.height = height;
    }
}
