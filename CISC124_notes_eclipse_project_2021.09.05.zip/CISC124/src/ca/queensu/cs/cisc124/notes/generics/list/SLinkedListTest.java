package ca.queensu.cs.cisc124.notes.generics.list;

import static org.junit.Assert.*;

import java.util.Iterator;

import org.junit.Test;

/**
 * Unit tests for the {@code SLinkedList} class.
 *
 */
public class SLinkedListTest {

	@Test
	public void test_add() {
		SList<Integer> t = new SLinkedList<>();
		t.add(9);
		assertEquals(1, t.size());
		assertEquals((Integer) 9, t.get(0));
	}
	
	@Test
	public void test_add2() {
		SList<Integer> t = new SLinkedList<>();
		t.add(9);
		t.add(8);
		assertEquals(2, t.size());
		assertEquals((Integer) 9, t.get(0));
		assertEquals((Integer) 8, t.get(1));
	}
	
	@Test
	public void test_add3() {
		SList<Integer> t = new SLinkedList<>();
		for (int i = 0; i < 17; i++) {
			t.add(i);
		}
		assertEquals(17, t.size());
		for (int i = 0; i < 17; i++) {
			assertEquals((Integer) i, t.get(i));
		}
	}

	@Test
	public void test_set() {
		SList<Integer> t = new SLinkedList<>();
		t.add(9);
		t.add(8);
		Integer got = t.set(0, 55);
		assertEquals(got, got);
		assertEquals((Integer) 55, t.get(0));
	}
	
	@Test
	public void test_addAt() {
		SList<Integer> t = new SLinkedList<>();
		t.add(0, 9);
		assertEquals(1, t.size());
		assertEquals((Integer) 9, t.get(0));
	}
	
	@Test
	public void test_addAt1() {
		SList<Integer> t = new SLinkedList<>();
		t.add(9);
		t.add(0, 100);
		assertEquals(2, t.size());
		assertEquals((Integer) 100, t.get(0));
		assertEquals((Integer) 9, t.get(1));
	}
	
	@Test
	public void test_addAt2() {
		SList<Integer> t = new SLinkedList<>();
		t.add(9);
		t.add(1, 100);
		assertEquals(2, t.size());
		assertEquals((Integer) 9, t.get(0));
		assertEquals((Integer) 100, t.get(1));
	}
	
	@Test
	public void test_removeAt() {
		SList<Integer> t = new SLinkedList<>();
		t.add(9);
		Integer got = t.remove(0);
		assertEquals(0, t.size());
		assertEquals((Integer) 9, got);
	}
	
	@Test
	public void test_removeAt1() {
		SList<Integer> t = new SLinkedList<>();
		t.add(9);
		t.add(8);
		Integer got = t.remove(0);
		assertEquals(1, t.size());
		assertEquals((Integer) 9, got);
		assertEquals((Integer) 8, t.get(0));
	}
	
	@Test
	public void test_removeAt2() {
		SList<Integer> t = new SLinkedList<>();
		t.add(9);
		t.add(8);
		Integer got = t.remove(1);
		assertEquals(1, t.size());
		assertEquals((Integer) 8, got);
		assertEquals((Integer) 9, t.get(0));
	}
	
	@Test
	public void test_hasNext() {
		SList<Integer> t = new SLinkedList<>();
		Iterator<Integer> it = t.iterator();
		assertFalse(it.hasNext());
	}
	
	@Test
	public void test_hasNext1() {
		SList<Integer> t = new SLinkedList<>();
		t.add(9);
		Iterator<Integer> it = t.iterator();
		assertTrue(it.hasNext());
	}
	
	@Test
	public void test_next() {
		SList<Integer> t = new SLinkedList<>();
		t.add(9);
		Iterator<Integer> it = t.iterator();
		assertEquals(it.next(), t.get(0));
	}
	
	@Test
	public void test_next2() {
		SList<Integer> t = new SLinkedList<>();
		for (int i = 0; i < 17; i++) {
			t.add(i);
		}
		Iterator<Integer> it = t.iterator();
		for (int i = 0; i < 17; i++) {
			assertEquals(t.get(i), it.next());
		}
	}
	
	@Test
	public void test_remove() {
		SList<Integer> t = new SLinkedList<>();
		t.add(9);
		Iterator<Integer> it = t.iterator();
		it.next();
		it.remove();
		assertEquals(0, t.size());
	}
	
	@Test
	public void test_remove1() {
		SList<Integer> t = new SLinkedList<>();
		for (int i = 0; i < 17; i++) {
			t.add(i);
		}
		for (Iterator<Integer> it = t.iterator(); it.hasNext(); ) {
			it.next();
			it.remove();
		}
		assertEquals(0, t.size());
	}
	
	@Test
	public void test_remove2() {
		SList<Integer> t = new SLinkedList<>();
		for (int i = 0; i < 17; i++) {
			t.add(i);
		}
		for (Iterator<Integer> it = t.iterator(); it.hasNext(); ) {
			Integer val = it.next();
			if (val % 2 == 0)
				it.remove();
		}
		assertEquals(8, t.size());
		for (int i = 0; i < t.size(); i++) {
			assertEquals((Integer) (i * 2 + 1), t.get(i));
		}
	}
}
