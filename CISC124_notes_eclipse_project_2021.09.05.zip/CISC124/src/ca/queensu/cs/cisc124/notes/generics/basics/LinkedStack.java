package ca.queensu.cs.cisc124.notes.generics.basics;

/**
 * A linked-list implementation of the {@code Stack} interface.
 *
 * @param <E> the type of the elements in the stack
 */
public class LinkedStack<E> implements Stack<E> {
    // the number of elements currently on the stack
    private int size;
    
    // the node containing the top element of the stack
    private Node<E> top;
    
    // static nested class representing nodes of the linked list
    private static class Node<E> {
            
        // the element stored in the node
        E elem;
    
        // the link to the next node in the sequence
        Node<E> next;
    
        Node(E elem, Node<E> next) {
            this.elem = elem;
            this.next = next;
        }
    }
    
    
    /**
     * Initialize an empty stack.
     */
    public LinkedStack() {
        this.size = 0;
        this.top = null;
    }


    @Override
    public int size() {
        return this.size;
    }


    @Override
    public void push(E elem) {
        Node<E> n = new Node<>(elem, this.top);
        this.top = n;
        this.size++;
    }


    @Override
    public E pop() {
        if (this.isEmpty()) {
            throw new RuntimeException("popped an empty stack");
        }
        E popped = this.top.elem;
        this.top = this.top.next;
        this.size--;
        return popped;
    }
    
    
    @Override
    public String toString() {
        StringBuilder b = new StringBuilder("Stack:");
        Node<E> n = this.top;
        while (n != null) {
            b.append('\n');
            b.append(n.elem);
            n = n.next;
        }
        return b.toString();
    }
    
    
    public static void main(String[] args) {
        Stack<String> t = new LinkedStack<>();
        t.push("A");
        t.push("B");
        t.push("C");
        System.out.println("size: " + t.size());
        System.out.println(t);
        System.out.println();
        
        String popped = t.pop();
        System.out.println("popped: " + popped);
        System.out.println("size: " + t.size());
        System.out.println(t);
        System.out.println();
        
        popped = t.pop();
        System.out.println("popped: " + popped);
        System.out.println("size: " + t.size());
        System.out.println(t);
        System.out.println();
        
        popped = t.pop();
        System.out.println("popped: " + popped);
        System.out.println("size: " + t.size());
        System.out.println(t);
        System.out.println();
        
        // force an exception
        t.pop();
    }
}
