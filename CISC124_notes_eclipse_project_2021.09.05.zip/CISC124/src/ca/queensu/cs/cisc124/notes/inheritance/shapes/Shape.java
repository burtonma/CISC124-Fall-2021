package ca.queensu.cs.cisc124.notes.inheritance.shapes;

/**
 * Superclass for shapes that have an independent width and height.
 * The width and height have a minimum value of 1 unit and
 * a maximum value of 100 units.
 */
public abstract class Shape {
    
    /**
     * The minimum width and height.
     */
    public static final double MIN_LENGTH = 1.0;
    
    /**
     * The maximum width and height.
     */
    public static final double MAX_LENGTH = 100.0;
    
    protected double width;
    protected double height;
    
    /**
     * Initializes this shape to have a width and height of 1.
     */
    public Shape() {
        this.width = 1.0;
        this.height = 1.0;
    }
    
    /**
     * Returns the width of this shape. The returned width is greater
     * than or equal to 1.0.
     *
     * @return the width of this shape
     */
    public double width() {
        return this.width;
    }
    
    /**
     * Returns the height of this shape. The returned height is greater
     * than or equal to 1.0.
     *
     * @return the height of this shape
     */
    public double height() {
        return this.height;
    }
    
    /**
     * Changes both the width and height of this shape to the specified
     * dimensions. The width and height must be greater than or equal to 1.
     *
     * @param width the width of the shape
     * @param height the height of the shape
     * @throws IllegalArgumentException if either width or height or is out of range
     */
    public void setDimensions(double width, double height) {
        if (width < MIN_LENGTH || height < MIN_LENGTH) {
            throw new IllegalArgumentException("dimension too small");
        }
        if (width > MAX_LENGTH || height > MAX_LENGTH) {
            throw new IllegalArgumentException("dimension too large");
        }
        this.width = width;
        this.height = height;
    }
    
    /**
     * Returns an upper bound on the area of this shape. Some shapes have
     * complicated geometry and computing the exact area of such shapes is
     * difficult. This method returns an estimate of the area of a shape
     * where the estimate is guaranteed to be greater than or equal to
     * the true area of the shape.
     *
     * <p>
     * This method simply returns a value equal to the width times the
     * height of the shape. Subclasses should override this method if they can 
     * provide a tighter upper bound.
     *
     * @return an upper bound on the area of the shape
     */ 
    public double areaUpperBound() {
        return this.width * this.height;
    }
    
    // other methods not shown
}